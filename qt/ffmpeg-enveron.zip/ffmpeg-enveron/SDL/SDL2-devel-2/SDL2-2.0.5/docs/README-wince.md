WinCE
=====

Windows CE is no longer supported by SDL.

We have left the CE support in SDL 1.2 for those that must have it, and we
have support for Windows Phone 8 and WinRT in SDL2, as of SDL 2.0.3.

--ryan.

